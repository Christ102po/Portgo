import { useEffect, useMemo, useState } from "react";
import { ChevronLeft, Users, Clock3, Armchair, Snowflake, Star } from "lucide-react";
import { useWizard } from "../../hooks/useWizard";
import { Label } from "../ui/Label";
import { Select } from "../ui/Select";
import { Button } from "../ui/Button";
import { Card, CardContent } from "../ui/Card";
import { apiClient } from "../../lib/apiClient";
import { cn } from "../../lib/cn";
import { routeLabel } from "../../lib/route";
import { useToast } from "../ui/Toast";
import { ACCOMMODATION_CLASSES } from "../../lib/accommodationClass";

const LOW_SEATS_THRESHOLD = 5;

const CLASS_ICONS = {
  ECONOMY: Armchair,
  TOURIST_AIRCON: Snowflake,
  BUSINESS: Star,
};

function AccommodationClassSelector({ classAvailability, value, onSelect, groupSize = 1 }) {
  return (
    <div className="mt-4 rounded-2xl border border-emerald-100 bg-emerald-50/50 p-3.5">
      <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-500">
        Type of Accommodation / Seat Class <span className="text-red-500">*</span>
      </p>
      <div className="grid grid-cols-1 gap-2 sm:grid-cols-3">
        {ACCOMMODATION_CLASSES.map((meta) => {
          const Icon = CLASS_ICONS[meta.value] || Armchair;
          const availability = classAvailability?.find((c) => c.className === meta.value);
          const isFull = !!availability?.isFull;
          const insufficientForGroup = availability?.seatsLeft != null && availability.seatsLeft < groupSize;
          const unavailable = isFull || insufficientForGroup;
          const selected = value === meta.value;
          return (
            <button
              key={meta.value}
              type="button"
              disabled={unavailable}
              onClick={() => onSelect(meta.value)}
              className={cn(
                "flex flex-col items-start gap-1 rounded-lg border-2 px-3 py-2.5 text-left transition-colors disabled:cursor-not-allowed disabled:opacity-50",
                selected ? "border-emerald-500 bg-gradient-to-br from-emerald-500 to-green-600 text-white shadow-md" : "border-emerald-100 bg-white hover:border-emerald-300 hover:bg-emerald-50"
              )}
            >
              <span className={cn("flex items-center gap-1.5 text-xs font-semibold", selected ? "text-white" : "text-slate-900")}>
                <Icon className="h-3.5 w-3.5" />
                {meta.label}
              </span>
              <span className={cn("text-[11px]", selected ? "text-emerald-50/90" : "text-slate-500")}>{meta.subtitle}</span>
              {availability?.capacity != null && (
                <span className={cn("text-[11px] font-medium", isFull ? "text-red-600" : selected ? "text-emerald-50" : "text-slate-500")}>
                  {isFull ? "Full" : insufficientForGroup ? `Needs ${groupSize} seats · only ${availability.seatsLeft} left` : `${availability.seatsLeft} of ${availability.capacity} seats left`}
                </span>
              )}
            </button>
          );
        })}
      </div>
      <p className="mt-2 text-[11px] text-slate-400">
        Boarding is first-come, first-served within your chosen class — no individual seat assignment.
      </p>
    </div>
  );
}

function SeatMeter({ schedule, groupSize = 1 }) {
  if (!schedule) return null;
  const isLow = !schedule.isFull && schedule.seatsLeft <= LOW_SEATS_THRESHOLD;
  const pct = Math.min(100, Math.round((schedule.bookedCount / schedule.capacity) * 100));
  const barColor = schedule.isFull ? "bg-red-500" : isLow ? "bg-amber-400" : "bg-emerald-500";
  const textColor = schedule.isFull ? "text-red-600" : isLow ? "text-amber-600" : "text-slate-900";

  return (
    <div className="mt-2 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2">
      <div className="flex items-center justify-between text-xs">
        <span className="flex items-center gap-1.5 font-medium text-slate-500">
          <Users className="h-3.5 w-3.5" />
          Passengers logged
        </span>
        <span className={cn("font-semibold", textColor)}>
          {schedule.bookedCount} / {schedule.capacity}
        </span>
      </div>
      <div className="mt-1.5 h-1.5 w-full overflow-hidden rounded-full bg-slate-200">
        <div className={cn("h-full rounded-full transition-all", barColor)} style={{ width: `${pct}%` }} />
      </div>
      {groupSize > 1 && (
        <p className={cn("mt-1.5 text-[11px] font-semibold", schedule.seatsLeft < groupSize ? "text-red-600" : "text-emerald-700")}>
          Your registration needs {groupSize} seats for the primary passenger and accompanying members.
        </p>
      )}
      {isLow && (
        <p className="mt-1.5 text-[11px] font-medium text-amber-600">
          Only {schedule.seatsLeft} slot{schedule.seatsLeft === 1 ? "" : "s"} left on this schedule!
        </p>
      )}
      {schedule.status === "DELAYED" && (
        <p className="mt-1.5 flex items-center gap-1 text-[11px] font-medium text-amber-600">
          <Clock3 className="h-3 w-3" />
          Delayed +{schedule.delayMinutes} min{schedule.delayReason ? ` — ${schedule.delayReason}` : ""}
        </p>
      )}
    </div>
  );
}

export function StepTripDetails() {
  const { state, dispatch } = useWizard();
  const [ships, setShips] = useState([]);
  const [schedules, setSchedules] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const { showToast } = useToast();
  const groupSize = 1 + state.groupMembers.length;

  useEffect(() => {
    setIsLoading(true);
    Promise.all([apiClient.get("/ships"), apiClient.get("/schedules")]).then(([shipsRes, schedulesRes]) => {
      setShips(shipsRes.data.ships);
      setSchedules(schedulesRes.data.schedules);
      setIsLoading(false);
    });
  }, []);

  function setField(field, value) {
    dispatch({ type: "SET_FIELD", field, value });
  }

  const shipOptions = useMemo(() => ships.map((s) => ({ value: s.id, label: s.name })), [ships]);

  const filteredSchedules = useMemo(
    () => (state.shipId ? schedules.filter((s) => s.shipId === state.shipId) : schedules),
    [schedules, state.shipId]
  );

  const scheduleOptions = useMemo(
    () =>
      filteredSchedules.map((s) => ({
        value: s.id,
        label: `${s.departureTime} — ${routeLabel(s.route)}${
          s.isFull ? "  (FULL)" : s.seatsLeft < groupSize ? `  (ONLY ${s.seatsLeft} LEFT · NEED ${groupSize})` : `  (${s.seatsLeft} left)`
        }${s.status === "DELAYED" ? `  · Delayed +${s.delayMinutes}m` : ""}`,
        disabled: s.isFull || s.seatsLeft < groupSize,
      })),
    [filteredSchedules, groupSize]
  );

  const selectedSchedule = useMemo(
    () => filteredSchedules.find((s) => s.id === state.scheduleId) || null,
    [filteredSchedules, state.scheduleId]
  );

  useEffect(() => {
    if (!selectedSchedule || selectedSchedule.isFull) return;
    if (selectedSchedule.seatsLeft <= LOW_SEATS_THRESHOLD) {
      showToast({
        title: "Limited capacity remaining",
        description: `Only ${selectedSchedule.seatsLeft} slot${selectedSchedule.seatsLeft === 1 ? "" : "s"} left on the ${selectedSchedule.departureTime} sailing.`,
        variant: "info",
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state.scheduleId]);

  const selectedClassAvailability = selectedSchedule?.classAvailability?.find(
    (item) => item.className === state.accommodationClass
  );
  const canContinue =
    state.shipId &&
    state.scheduleId &&
    selectedSchedule &&
    !selectedSchedule.isFull &&
    selectedSchedule.seatsLeft >= groupSize &&
    state.accommodationClass &&
    (!selectedClassAvailability || selectedClassAvailability.seatsLeft >= groupSize);

  return (
    <div>
      <h2 className="section-title">Trip Selection</h2>
      <p className="section-subtitle mb-6">
        Select the vessel, schedule, and accommodation for your trip.
      </p>

      <Card className="mx-auto max-w-2xl overflow-hidden border-emerald-100 shadow-[0_22px_50px_-32px_rgba(6,78,59,0.65)]">
        <div className="bg-gradient-to-r from-emerald-700 to-green-600 px-5 py-5 text-white sm:px-6">
          <p className="text-xs font-extrabold uppercase tracking-[0.16em] text-emerald-100">PORTGO sailing</p>
          <p className="mt-1 text-lg font-black">Choose your trip</p>
        </div>
        <CardContent className="grid grid-cols-1 gap-5 pt-6 sm:grid-cols-2">
          <div>
            <Label>Ship / Vessel</Label>
            <Select
              value={state.shipId}
              onValueChange={(v) => {
                setField("shipId", v);
                setField("scheduleId", null);
                setField("accommodationClass", null);
              }}
              options={shipOptions}
              placeholder={isLoading ? "Loading..." : "Select a ship"}
              disabled={isLoading}
            />
          </div>

          <div>
            <Label>Departure Schedule</Label>
            <Select
              value={state.scheduleId}
              onValueChange={(v) => {
                setField("scheduleId", v);
                setField("accommodationClass", null);
              }}
              options={scheduleOptions}
              placeholder={isLoading ? "Loading..." : "Select a time slot"}
              disabled={isLoading || !state.shipId}
            />
          </div>

          {selectedSchedule && (
            <div className="sm:col-span-2">
              <SeatMeter schedule={selectedSchedule} groupSize={groupSize} />
              <AccommodationClassSelector
                classAvailability={selectedSchedule.classAvailability}
                value={state.accommodationClass}
                onSelect={(className) => setField("accommodationClass", className)}
                groupSize={groupSize}
              />
            </div>
          )}
        </CardContent>
      </Card>

      <div className="mobile-action-bar">
        <Button variant="outline" size="lg" onClick={() => dispatch({ type: "PREV_STEP" })}>
          <ChevronLeft className="h-4 w-4" /> Back
        </Button>
        <Button variant="kiosk" size="lg" className="h-auto w-full sm:w-auto px-8 py-3.5 rounded-xl" disabled={!canContinue} onClick={() => dispatch({ type: "NEXT_STEP" })}>
          Continue
        </Button>
      </div>
    </div>
  );
}
